<?php

use Illuminate\Database\Seeder;
use App\Models\MelakaArea;

class MelakaAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        MelakaArea::create([
        	'area_name' => 'ALOR GAJAH'
        ]);
        MelakaArea::create([
        	'area_name' => 'ASAHAN'
        ]);
        MelakaArea::create([
        	'area_name' => 'AYER KEROH'
        ]);
        MelakaArea::create([
        	'area_name' => 'BANDAR HILIR'
        ]);
    }
}
