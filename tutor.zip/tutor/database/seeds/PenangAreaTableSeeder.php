<?php

use Illuminate\Database\Seeder;
use App\Models\PenangArea;

class PenangAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        PenangArea::create([
        	'area_name' => 'AIR TAWAR'
        ]);
        PenangArea::create([
        	'area_name' => 'ALMA'
        ]);
        PenangArea::create([
        	'area_name' => 'AYER ITAM'
        ]);
        PenangArea::create([
        	'area_name' => 'BAGAN JERMAL'
        ]);
    }
}
