<?php

use Illuminate\Database\Seeder;
use App\Models\TerengganuArea;

class TerengganuAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        TerengganuArea::create([
        	'area_name' => 'BESUT'
        ]);
        TerengganuArea::create([
        	'area_name' => 'DUNGUN'
        ]);
        TerengganuArea::create([
        	'area_name' => 'HULU TERENGGANU'
        ]);
        TerengganuArea::create([
        	'area_name' => 'KEMAMAN'
        ]);
    }
}
