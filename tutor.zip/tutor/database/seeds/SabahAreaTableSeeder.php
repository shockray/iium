<?php

use Illuminate\Database\Seeder;
use App\Models\SabahArea;

class SabahAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        SabahArea::create([
        	'area_name' => 'BEAUFORT'
        ]);
        SabahArea::create([
        	'area_name' => 'BELURAN'
        ]);
        SabahArea::create([
        	'area_name' => 'BONGAWAN'
        ]);
        SabahArea::create([
        	'area_name' => 'KENINGAU'
        ]);
    }
}
