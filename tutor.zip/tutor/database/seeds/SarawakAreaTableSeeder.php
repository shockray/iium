<?php

use Illuminate\Database\Seeder;
use App\Models\SarawakArea;

class SarawakAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        SarawakArea::create([
        	'area_name' => 'ASAJAYA'
        ]);
        SarawakArea::create([
        	'area_name' => 'BALINGIAN'
        ]);
        SarawakArea::create([
        	'area_name' => 'BARAM'
        ]);
        SarawakArea::create([
        	'area_name' => 'BAU'
        ]);
    }
}
