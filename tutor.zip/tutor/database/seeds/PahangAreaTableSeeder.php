<?php

use Illuminate\Database\Seeder;
use App\Models\PahangArea;

class PahangAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        PahangArea::create([
        	'area_name' => 'BALOK'
        ]);
        PahangArea::create([
        	'area_name' => 'BANDAR PUSAT JENGKA'
        ]);
        PahangArea::create([
        	'area_name' => 'BANDAR TUN ABDUL RAZAK'
        ]);
        PahangArea::create([
        	'area_name' => 'BENTA'
        ]);
    }
}
