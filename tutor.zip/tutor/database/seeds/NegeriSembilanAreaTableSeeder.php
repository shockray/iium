<?php

use Illuminate\Database\Seeder;
use App\Models\NegeriSembilanArea;

class NegeriSembilanAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        NegeriSembilanArea::create([
        	'area_name' => 'BAHAU'
        ]);
        NegeriSembilanArea::create([
        	'area_name' => 'BANDAR BARU '
        ]);
        NegeriSembilanArea::create([
        	'area_name' => 'SERTING'
        ]);
        NegeriSembilanArea::create([
        	'area_name' => 'BATANG MELAKA'
        ]);
    }
}
