<?php

use Illuminate\Database\Seeder;
use App\Models\JohorArea;

class JohorAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        JohorArea::create([
        	'area_name' => 'Bukit Gambir'
        ]);
        JohorArea::create([
        	'area_name' => 'Bukit Pasir'
        ]);
        JohorArea::create([
        	'area_name' => 'Chaah'
        ]);
        JohorArea::create([
        	'area_name' => 'Gelang Patah'
        ]);
    }
}