<?php

use Illuminate\Database\Seeder;
use App\Models\SelangorArea;

class SelangorAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        SelangorArea::create([
        	'area_name' => 'ALAM IMPIANA'
        ]);
        SelangorArea::create([
        	'area_name' => 'AMAN PERDANA'
        ]);
        SelangorArea::create([
        	'area_name' => 'AMPANG'
        ]);
        SelangorArea::create([
        	'area_name' => 'BANDAR BOTANIC'
        ]);
    }
}
