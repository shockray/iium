<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
    	$this->call(UserTableSeeder::class);
        $this->call(SabahAreaTableSeeder::class);
        $this->call(SarawakAreaTableSeeder::class);
        $this->call(KelantanAreaTableSeeder::class);
        $this->call(TerengganuAreaTableSeeder::class);
        $this->call(MelakaAreaTableSeeder::class);
        $this->call(PerakAreaTableSeeder::class);
        $this->call(NegeriSembilanAreaTableSeeder::class);
        $this->call(PenangAreaTableSeeder::class);
        $this->call(KedahAreaTableSeeder::class);
        $this->call(PahangAreaTableSeeder::class);
        $this->call(JohorAreaTableSeeder::class);
        $this->call(SelangorAreaTableSeeder::class);
    }
}
