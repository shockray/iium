<?php

use Illuminate\Database\Seeder;
use App\Models\PerakArea;

class PerakAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        PerakArea::create([
        	'area_name' => 'AYER TAWAR'
        ]);
        PerakArea::create([
        	'area_name' => 'BAGAN DATOH'
        ]);
        PerakArea::create([
        	'area_name' => 'BAGAN SERAI'
        ]);
        PerakArea::create([
        	'area_name' => 'BATU GAJAH'
        ]);
    }
}
