<?php

use Illuminate\Database\Seeder;
use App\Models\KelantanArea;

class KelantanAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        KelantanArea::create([
        	'area_name' => 'AYER LANAS'
        ]);
        KelantanArea::create([
        	'area_name' => 'BACHOK'
        ]);
        KelantanArea::create([
        	'area_name' => 'CHERANG RUKU'
        ]);
        KelantanArea::create([
        	'area_name' => 'DABONG'
        ]);
    }
}
