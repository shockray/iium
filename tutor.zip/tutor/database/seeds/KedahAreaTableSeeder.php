<?php

use Illuminate\Database\Seeder;
use App\Models\KedahArea;

class KedahAreaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        KedahArea::create([
        	'area_name' => 'ALOR SETAR'
        ]);
        KedahArea::create([
        	'area_name' => 'AYER HITAM'
        ]);
        KedahArea::create([
        	'area_name' => 'BALING'
        ]);
        KedahArea::create([
        	'area_name' => 'BANDAR BAHARU'
        ]);
    }
}
