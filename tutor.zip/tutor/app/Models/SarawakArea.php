<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SarawakArea extends Model
{
    protected $guarded = [];
}
