<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JohorArea extends Model
{
    protected $guarded = [];
}
