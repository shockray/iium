<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MelakaArea;
use App\Models\Joblist;

class JobMelakaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $job_list = Joblist::where('state','Melaka')->get();
        // dd($job_list);
        return view('job_melaka.index',compact('job_list'));
    }

    public function indexUser()
    {
        $job_list = Joblist::where('state','Melaka')->get();
        // dd($job_list);
        return view('job_melaka.index-user',compact('job_list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $areas = MelakaArea::all();
        return view('job_melaka.create', compact('areas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'area' => 'required',
            'detail' => 'required',
        ]);
        Joblist::create([
            'area'      => $request->area,
            'state'     => 'Melaka',
            'detail'    => $request->detail
        ]);

        return redirect('/job/melaka');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $job = Joblist::find($id);
        $areas = MelakaArea::all();
        return view('job_melaka.edit', compact('areas','job'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $request->validate([
            'area' => 'required',
            'detail' => 'required',
        ]);

        Joblist::find($id)->update([
            'area'      => $request->area,
            'state'     => 'Melaka',
            'detail'    => $request->detail
        ]);

        return redirect('/job/melaka');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Joblist::find($id)->delete();

        return redirect()->back();
    }
}
