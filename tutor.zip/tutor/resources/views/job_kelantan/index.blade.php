@extends('layout.app')
@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="header">
                <h4 class="title">Job Detail</h4>
                <p class="category">24 Hours performance</p>
            </div>
            <div class="content">
            	<div class="form-group">
				    <a href="/job/kelantan/create" class="btn btn-success">Add New</a>
				</div>
				<table class="table table-responsive">
				    <caption>List Job</caption>
				    <thead>
				        <tr>
				            <th>No</th>
				            <th>Job ID</th>
				            <th>Area</th>
				            <th>Detail</th>
				            <th>Update</th>
				            <th>Delete</th>
				        </tr>
				    </thead>
				    <tbody>
				    	@foreach($job_list as $i => $job)
				    	<tr>
				    		<td>{{++$i}}</td>
				    		<td>JOB KT{{$job->id}}</td>
				    		<td>{{$job->area}}</td>
				    		<td>{{$job->detail}}</td>
				    		<td>
				    			<a href="{{url('job/kelantan/edit/'.$job->id)}}" class="btn btn-primary"><span><i class="fa fa-edit"></i></span></a>
				    		</td>
				    		<td>
				    			<a href="{{url('job/kelantan/delete/'.$job->id)}}" class="btn btn-danger"><span><i class="fa fa-trash"></i></span></a>
				    		</td>
				    	</tr>
				    	@endforeach
				    </tbody>
				</table>
            </div>		
        </div>
	</div>
</div>
@endsection