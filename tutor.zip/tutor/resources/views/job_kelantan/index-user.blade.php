@extends('layout_user.app')
@section('content')
	
	 @foreach($job_list as $i => $job)
	<div class="row" style="border-bottom: 1px solid;margin-bottom: 30px;">
		<div class="col-md-12">
			<div class="list-inline text-left">
	    <div class="form-group">
	       
	            <div class="form-group">
	            	<div class="bold">
		            	{{$job->area}} | KELANTAN
		            </div>
	            </div>

	            <div class="form-group">
	            	JOB KT{{$job->id}}
	            </div>

	            <div class="form-group">
	            	{{$job->detail}}
	            </div>
	            <a href="http://www.wasap.my/60173562466" class="btn btn-success">Whatsapp untuk apply</a>
	        
	    </div>
	</div>
		</div>

	</div>	
	@endforeach


@endsection