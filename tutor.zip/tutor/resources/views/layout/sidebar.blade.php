<div class="sidebar" data-color="blue" data-image="{{asset('admin/assets/img/sidebar-5.jpg')}}">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="/home" class="simple-text">
                    TuitionJob Admin
                </a>
            </div>

            <ul class="nav">
                    <li>
                    <a href="/home">
                        <i class="pe-7s-note2"></i>
                        <p>Job List</p>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="pe-7s-user"></i>
                        <p>User Profile</p>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="pe-7s-news-paper"></i>
                        <p>Archive</p>
                    </a>
                </li>
                <!-- <li>
                    <a href="icons.html">
                        <i class="pe-7s-science"></i>
                        <p>Place</p>
                    </a>
                </li> -->
                <li>
                    <a href="#">
                        <i class="pe-7s-map-marker"></i>
                        <p>Place</p>
                    </a>
                </li>
                                
            </ul>
        </div>
    </div>