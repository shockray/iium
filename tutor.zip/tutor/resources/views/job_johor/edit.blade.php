@extends('layout.app')
@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="header">
				<h4 class="title">Edit Job Detail Johor</h4>
			</div>
			@if ($errors->any())
		    <div class="alert alert-danger">
		        <ul>
		            @foreach ($errors->all() as $error)
		                <li>{{ $error }}</li>
		            @endforeach
		        </ul>
		    </div>
			@endif
			<div class="content">
				<form action="{{url('/job/johor/edit/'.$job->id.'/update')}}" method="post">
				    <input name="_method" type="hidden" value="PATCH">		
				    {{ csrf_field() }}
				<div class="form-group">
                    <label for="area">Area</label>
                        <select name="area" class="form-control">
                            <option disabled selected value=""> -- Please Select -- </option>
                            @foreach($areas as $area)
								<option value="{{$area->area_name}}"> {{$area->area_name}} </option>
                            @endforeach
                       </select>
                   </div>

                  <div class="form-group">
                  	<label for="area">Details</label>
                  	<textarea name="detail" rows="10" style="width: 100%">{{$job->detail}}</textarea>
                  </div>

	              	<div class="form-group">
	                    <button type="submit" class="btn btn-success">Update</button>
	                    <a href="/job/johor" class="btn btn-default">Cancel</a>
	        		</div>
	        		</form>
			</div>
		</div>
	</div>
</div>
@endsection