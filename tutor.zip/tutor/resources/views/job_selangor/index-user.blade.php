@extends('layout_user.app')
@section('content')
	
	 @foreach($job_list as $i => $job)
	<div class="row">
		<div class="col-md-12" style="padding-right: 5%;padding-left:5%">
		
            <div class="form-group">
            	<div>
	            	<strong>{{$job->area}} | SELANGOR/KL/PUTRAJAYA</strong>
	            </div>
            </div>

            <div class="form-group">
            	JOB SL{{$job->id}}
            </div>

            <div class="form-group">
            	{{$job->detail}}
            </div>
            <a href="http://www.wasap.my/60173562466" class="btn btn-success">Whatsapp untuk apply</a>
			        
		</div>
<hr>	
	</div>

	@endforeach


@endsection