@extends('user_view.app')
@section('content')
			
	<div class="list-inline text-left">
	    <div class="form-group">
	        @foreach($job_list as $i => $job)
	            <div class="form-group">
	            	<div class="bold">
		            	{{$job->area}} | SELANGOR/KL/PUTRAJAYA
		            </div>
	            </div>

	            <div class="form-group">
	            	JOB SL{{++$i}}
	            </div>

	            <div class="form-group">
	            	{{$job->detail}}
	            </div>
	            <a href="http://www.wasap.my/60173562466" class="btn btn-success">Whatsapp untuk apply</a>
	        @endforeach
	    </div>
	</div>


@endsection