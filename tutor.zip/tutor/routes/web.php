<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('summernoteeditor',array('as'=>'summernoteeditor.get','uses'=>'SummernotefileController@getSummernoteeditor'));



// Route::post('summernoteeditor',array('as'=>'summernoteeditor.post','uses'=>'SummernotefileController@postSummernoteeditor'));


Route::group(['middleware' => 'auth'], function(){
	
Route::get('/', 'HomeController@index')->name('home');
	
	// Job List
	Route::get('/home','JobListController@index')->name('job-list.index');


	// Job Selangor
	Route::get('/job/selangor','JobSelangorController@index')->name('job-selangor.index');

	Route::get('/job/selangor/create','JobSelangorController@create')->name('job-selangor.create');

	Route::post('/job/selangor/store', 'JobSelangorController@store')->name('job-selangor.store');

	Route::get('/job/selangor/edit/{id}', 'JobSelangorController@edit')->name('job-selangor.edit');

	Route::patch('/job/selangor/edit/{id}/update', 'JobSelangorController@update')->name('job-selangor.update');

	Route::get('/job/selangor/delete/{id}', 'JobSelangorController@destroy')->name('job-selangor.delete');


	// Job Johor 
	Route::get('/job/johor','JobJohorController@index')->name('job-johor.index');

	Route::get('/job/johor/create', 'JobJohorController@create')->name('job-johor.create');

	Route::post('/job/johor/store', 'JobJohorController@store')->name('job-johor.store');

	Route::get('/job/johor/edit/{id}', 'JobJohorController@edit')->name('job-johor.edit');

	Route::patch('/job/johor/edit/{id}/update', 'JobJohorController@update')->name('job-johor.update');

	Route::get('/job/johor/delete/{id}', 'JobJohorController@destroy')->name('job-johor.delete');

	// Job Pahang 
	Route::get('/job/pahang','JobPahangController@index')->name('job-pahang.index');

	Route::get('/job/pahang/create', 'JobPahangController@create')->name('job-pahang.create');

	Route::post('/job/pahang/store', 'JobPahangController@store')->name('job-pahang.store');

	Route::get('/job/pahang/edit/{id}', 'JobPahangController@edit')->name('job-pahang.edit');

	Route::patch('/job/pahang/edit/{id}/update', 'JobPahangController@update')->name('job-pahang.update');

	Route::get('/job/pahang/delete/{id}', 'JobPahangController@destroy')->name('job-pahang.delete');

	// Job Kedah 
	Route::get('/job/kedah','JobKedahController@index')->name('job-kedah.index');

	Route::get('/job/kedah/create', 'JobKedahController@create')->name('job-kedah.create');

	Route::post('/job/kedah/store', 'JobKedahController@store')->name('job-kedah.store');

	Route::get('/job/kedah/edit/{id}', 'JobKedahController@edit')->name('job-kedah.edit');

	Route::patch('/job/kedah/edit/{id}/update', 'JobKedahController@update')->name('job-kedah.update');

	Route::get('/job/kedah/delete/{id}', 'JobKedahController@destroy')->name('job-kedah.delete');

	// Job Penang 
	Route::get('/job/penang','JobPenangController@index')->name('job-penang.index');

	Route::get('/job/penang/create', 'JobPenangController@create')->name('job-penang.create');

	Route::post('/job/penang/store', 'JobPenangController@store')->name('job-penang.store');

	Route::get('/job/penang/edit/{id}', 'JobPenangController@edit')->name('job-penang.edit');

	Route::patch('/job/penang/edit/{id}/update', 'JobPenangController@update')->name('job-penang.update');

	Route::get('/job/penang/delete/{id}', 'JobPenangController@destroy')->name('job-penang.delete');

	// Job NegeriSembilan 
	Route::get('/job/negerisembilan','JobNegeriSembilanController@index')->name('job-negerisembilan.index');

	Route::get('/job/negerisembilan/create', 'JobNegeriSembilanController@create')->name('job-negerisembilan.create');

	Route::post('/job/negerisembilan/store', 'JobNegeriSembilanController@store')->name('job-negerisembilan.store');

	Route::get('/job/negerisembilan/edit/{id}', 'JobNegeriSembilanController@edit')->name('job-negerisembilan.edit');

	Route::patch('/job/negerisembilan/edit/{id}/update', 'JobNegeriSembilanController@update')->name('job-negerisembilan.update');

	Route::get('/job/negerisembilan/delete/{id}', 'JobNegeriSembilanController@destroy')->name('job-negerisembilan.delete');

	// Job Perak 
	Route::get('/job/perak','JobPerakController@index')->name('job-perak.index');

	Route::get('/job/perak/create', 'JobPerakController@create')->name('job-perak.create');
	
	Route::post('/job/perak/store', 'JobPerakController@store')->name('job-perak.store');

	Route::get('/job/perak/edit/{id}', 'JobPerakController@edit')->name('job-perak.edit');

	Route::patch('/job/perak/edit/{id}/update', 'JobPerakController@update')->name('job-perak.update');

	Route::get('/job/perak/delete/{id}', 'JobPerakController@destroy')->name('job-perak.delete');

	// Job Melaka 
	Route::get('/job/melaka','JobMelakaController@index')->name('job-melaka.index');

	Route::get('/job/melaka/create', 'JobMelakaController@create')->name('job-melaka.create');
	
	Route::post('/job/melaka/store', 'JobMelakaController@store')->name('job-melaka.store');

	Route::get('/job/melaka/edit/{id}', 'JobMelakaController@edit')->name('job-melaka.edit');

	Route::patch('/job/melaka/edit/{id}/update', 'JobMelakaController@update')->name('job-melaka.update');

	Route::get('/job/melaka/delete/{id}', 'JobMelakaController@destroy')->name('job-melaka.delete');

	// Job Terengganu 
	Route::get('/job/terengganu','JobTerengganuController@index')->name('job-terengganu.index');

	Route::get('/job/terengganu/create', 'JobTerengganuController@create')->name('job-terengganu.create');
	
	Route::post('/job/terengganu/store', 'JobTerengganuController@store')->name('job-terengganu.store');

	Route::get('/job/terengganu/edit/{id}', 'JobTerengganuController@edit')->name('job-terengganu.edit');

	Route::patch('/job/terengganu/edit/{id}/update', 'JobTerengganuController@update')->name('job-terengganu.update');

	Route::get('/job/terengganu/delete/{id}', 'JobTerengganuController@destroy')->name('job-terengganu.delete');

	// Job Kelantan 
	Route::get('/job/kelantan','JobKelantanController@index')->name('job-kelantan.index');

	Route::get('/job/kelantan/create', 'JobKelantanController@create')->name('job-kelantan.create');
	
	Route::post('/job/kelantan/store', 'JobKelantanController@store')->name('job-kelantan.store');

	Route::get('/job/kelantan/edit/{id}', 'JobKelantanController@edit')->name('job-kelantan.edit');

	Route::patch('/job/kelantan/edit/{id}/update', 'JobKelantanController@update')->name('job-kelantan.update');

	Route::get('/job/kelantan/delete/{id}', 'JobKelantanController@destroy')->name('job-kelantan.delete');

	// Job Sarawak 
	Route::get('/job/sarawak','JobSarawakController@index')->name('job-sarawak.index');

	Route::get('/job/sarawak/create', 'JobSarawakController@create')->name('job-sarawak.create');
	
	Route::post('/job/sarawak/store', 'JobSarawakController@store')->name('job-sarawak.store');

	Route::get('/job/sarawak/edit/{id}', 'JobSarawakController@edit')->name('job-sarawak.edit');

	Route::patch('/job/sarawak/edit/{id}/update', 'JobSarawakController@update')->name('job-sarawak.update');

	Route::get('/job/sarawak/delete/{id}', 'JobSarawakController@destroy')->name('job-sarawak.delete');

	// Job Sabah 
	Route::get('/job/sabah','JobSabahController@index')->name('job-sabah.index');

	Route::get('/job/sabah/create', 'JobSabahController@create')->name('job-sabah.create');
	
	Route::post('/job/sabah/store', 'JobSabahController@store')->name('job-sabah.store');

	Route::get('/job/sabah/edit/{id}', 'JobSabahController@edit')->name('job-sabah.edit');

	Route::patch('/job/sabah/edit/{id}/update', 'JobSabahController@update')->name('job-sabah.update');

	Route::get('/job/sabah/delete/{id}', 'JobSabahController@destroy')->name('job-sabah.delete');


});

Route::group(['middleware' => 'guest'], function(){
	Route::get('/', 'UserViewController@index')->name('user');

	Route::get('/job/selangor/list','JobSelangorController@indexUser')->name('selangor.index-user');

	Route::get('/job/johor/list','JobJohorController@indexUser')->name('johor.index-user');

	Route::get('/job/pahang/list','JobPahangController@indexUser')->name('pahang.index-user');

	Route::get('/job/kedah/list','JobKedahController@indexUser')->name('kedah.index-user');

	Route::get('/job/penang/list','JobPenangController@indexUser')->name('penang.index-user');

	Route::get('/job/negerisembilan/list','JobNegeriSembilanController@indexUser')->name('negerisembilan.index-user');

	Route::get('/job/perak/list','JobPerakController@indexUser')->name('perak.index-user');

	Route::get('/job/melaka/list','JobMelakaController@indexUser')->name('melaka.index-user');

	Route::get('/job/terengganu/list','JobTerengganuController@indexUser')->name('terengganu.index-user');

	Route::get('/job/kelantan/list','JobKelantanController@indexUser')->name('kelantan.index-user');

	Route::get('/job/sarawak/list','JobSarawakController@indexUser')->name('sarawak.index-user');

	Route::get('/job/sabah/list','JobSabahController@indexUser')->name('sabah.index-user');
	


});

Route::get('summernoteeditor',array('as'=>'summernoteeditor.get','uses'=>'SummernoteController@getSummernoteeditor'));

Route::get('summernoteeditor',array('as'=>'summernoteeditor.post','uses'=>'SummernoteController@postSummernoteeditor'));



Auth::routes();



