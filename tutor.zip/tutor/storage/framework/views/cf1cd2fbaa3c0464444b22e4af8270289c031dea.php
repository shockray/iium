<?php /* C:\xampp\htdocs\tutor\resources\views/user_view/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
			
			<div class="list-inline text-center">
			    <div class="form-group">
			        <a href="/job/selangor/list" class="btn btn-primary">SELANGOR/KL/PUTRAJAYA</a>
			    </div>
			</div>

			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/johor/list" class="btn btn-primary">JOHOR</a>
			    </div> 
			</div>

			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/pahang/list" class="btn btn-primary">PAHANG</a>
			    </div> 
			</div>
			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/kedah/list" class="btn btn-primary">KEDAH</a>
			    </div> 
			</div>

			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/penang/list" class="btn btn-primary">PENANG</a>
			            
			    </div> 
			</div>

			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/negerisembilan/list" class="btn btn-primary">NEGERI SEMBILAN</a>
			            
			    </div> 
			</div>

			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/perak/list" class="btn btn-primary">PERAK</a>
			            
			    </div> 
			</div>


			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/melaka/list" class="btn btn-primary">MELAKA</a>
			            
			    </div> 
			</div>


			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/terengganu/list" class="btn btn-primary">TERENGGANU</a>
			            
			    </div> 
			</div>


			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/kelantan/list" class="btn btn-primary">KELANTAN</a>
			            
			    </div> 
			</div>

			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/sarawak/list" class="btn btn-primary">SARAWAK</a>
			            
			    </div> 
			</div>

			<div class="list-inline text-center">
			    <div class="form-group">
			            <a href="/job/sabah/list" class="btn btn-primary">SABAH</a>
			            
			    </div> 
			</div>
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>