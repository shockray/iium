<?php /* C:\xampp\htdocs\tutor\resources\views/job_penang/index-user.blade.php */ ?>
<?php $__env->startSection('content'); ?>
	
	 <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="row" style="border-bottom: 1px solid;margin-bottom: 30px;">
		<div class="col-md-12">
			<div class="list-inline text-left">
	    <div class="form-group">
	       
	            <div class="form-group">
	            	<div class="bold">
		            	<?php echo e($job->area); ?> | PENANG
		            </div>
	            </div>

	            <div class="form-group">
	            	JOB PN<?php echo e($job->id); ?>

	            </div>

	            <div class="form-group">
	            	<?php echo e($job->detail); ?>

	            </div>
	            <a href="http://www.wasap.my/60173562466" class="btn btn-success">Whatsapp untuk apply</a>
	        
	    </div>
	</div>
		</div>

	</div>	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>