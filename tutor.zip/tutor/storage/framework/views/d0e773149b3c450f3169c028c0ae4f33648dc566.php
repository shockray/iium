<?php /* C:\xampp\htdocs\tutor\resources\views/joblist/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Job Detail</h4>
                </div>
                <div class="content">
                    <div class="form-group">
                        <a href="/job/selangor" class="btn btn-success">Selangor/Kuala Lumpur/Putrajaya</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/johor" class="btn btn-success">Johor</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/pahang" class="btn btn-success">Pahang</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/kedah" class="btn btn-success">Kedah</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/penang" class="btn btn-success">Penang</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/negerisembilan" class="btn btn-success">Negeri Sembilan</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/perak" class="btn btn-success">Perak</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/melaka" class="btn btn-success">Melaka</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/terengganu" class="btn btn-success">Terengganu</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/kelantan" class="btn btn-success">Kelantan</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/sarawak" class="btn btn-success">Sarawak</a>
                    </div>

                    <div class="form-group">
                        <a href="/job/sabah" class="btn btn-success">Sabah</a>
                    </div>
                </div>
            </div>
        </div>
    </div>



               
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>