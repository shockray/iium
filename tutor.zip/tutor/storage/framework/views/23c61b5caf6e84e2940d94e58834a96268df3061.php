<?php /* C:\xampp\htdocs\tutor\resources\views/layout/footer.blade.php */ ?>
<footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                   Tuition Job 2019 © All Rights Reserved.
                </p>
            </div>
        </footer>