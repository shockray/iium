<?php /* C:\xampp\htdocs\tutor\resources\views/job_negerisembilan/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="header">
				<h4 class="title">Job Detail</h4>
			</div>
			<div class="content">
				<form action="<?php echo e(url('/job/negerisembilan/store')); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
                    <label for="area">Area</label>
                        <select name="area" class="form-control">
                            <option disabled selected value=""> -- Please Select -- </option>
                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($area->area_name); ?>"> <?php echo e($area->area_name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                   </div>

                  <div class="form-group">
                  	<label for="area">Details</label>
                  	<textarea name="detail" rows="10" style="width: 100%" placeholder="Insert Details">
                  	</textarea>
                  </div>

	              	<div class="form-group">
	                    <button type="submit" class="btn btn-success">Save</button>
	                    <a href="/job/negerisembilan" class="btn btn-default">Cancel</a>
	        		</div>
	        		</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>