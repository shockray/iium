<?php /* C:\xampp\htdocs\tutor\resources\views/job_selangor/index-user.blade.php */ ?>
<?php $__env->startSection('content'); ?>
	
	 <?php $__currentLoopData = $job_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-md-12" style="padding-right: 5%;padding-left:5%">
		
            <div class="form-group">
            	<div>
	            	<strong><?php echo e($job->area); ?> | SELANGOR/KL/PUTRAJAYA</strong>
	            </div>
            </div>

            <div class="form-group">
            	JOB SL<?php echo e($job->id); ?>

            </div>

            <div class="form-group">
            	<?php echo e($job->detail); ?>

            </div>
            <a href="http://www.wasap.my/60173562466" class="btn btn-success">Whatsapp untuk apply</a>
			        
		</div>
<hr>	
	</div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>